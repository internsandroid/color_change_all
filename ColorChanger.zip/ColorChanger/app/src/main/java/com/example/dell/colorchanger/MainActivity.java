package com.example.dell.colorchanger;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText et;
    Button red, green, blue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et = (EditText) findViewById(R.id.editText);
        red = (Button) findViewById(R.id.red);
        green = (Button) findViewById(R.id.green);
        blue = (Button) findViewById(R.id.blue);

        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            /**
             * To change the colours of the respective buttons according to the input in editText
             * @param s
             */
            @Override
            public void afterTextChanged(Editable s) {
                int red_on = 0, green_on = 0, blue_on = 0;
                String str = et.getText().toString();
                String[] items = str.split(",");
                for (int i = 0; i < items.length; i++) {
                    String item = items[i];
                    if (item.toLowerCase().equals("red")) {
                        red.setBackgroundColor(Color.parseColor("#ff0000"));
                        red_on = 1;
                    }
                    if (item.toLowerCase().equals("green")) {
                        green.setBackgroundColor(Color.parseColor("#00ff00"));
                        green_on = 1;
                    }
                    if (item.toLowerCase().equals("blue")) {
                        blue.setBackgroundColor(Color.parseColor("#0000ff"));
                        blue_on = 1;
                    }
                }
                if (red_on == 0)
                    red.setBackgroundColor(Color.parseColor("#d3d3d3"));
                if (blue_on == 0)
                    blue.setBackgroundColor(Color.parseColor("#d3d3d3"));
                if (green_on == 0)
                    green.setBackgroundColor(Color.parseColor("#d3d3d3"));
                java.util.Arrays.fill(items, "");
            }
        });
    }
}
