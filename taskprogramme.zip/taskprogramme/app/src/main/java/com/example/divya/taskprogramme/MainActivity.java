package com.example.divya.taskprogramme;

import android.graphics.Color;
import android.renderscript.Sampler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    Button button,button2,button3;
    EditText edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        edit = (EditText) findViewById(R.id.editText);

        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String a[] = s.toString().split(",");
                int i=a.length;
                for(int j=0;j<i;j++) {

                    if (a[j].equals("red")) {

                        int color = Color.rgb(255, 0, 0);
                        button.setBackgroundColor(color);
                    } else if (a[j].equals("green")) {

                        int color1 = Color.rgb(0, 255, 0);
                        button3.setBackgroundColor(color1);
                    } else if (a[j].equals("blue")) {
                        int color2 = Color.rgb(0, 0, 255);
                        button2.setBackgroundColor(color2);
                    } else {
                        button.setBackgroundColor(Color.rgb(255, 255, 255));
                        button2.setBackgroundColor(Color.rgb(255, 255, 255));
                        button3.setBackgroundColor(Color.rgb(255, 255, 255));
                    }

                }
            }
        } );
    }


}
