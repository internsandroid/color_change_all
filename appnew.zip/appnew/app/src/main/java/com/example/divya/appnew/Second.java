package com.example.divya.appnew;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Second extends AppCompatActivity {
    Button b,b1,b2,b3;
    EditText edit,edit2;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        b=(Button)findViewById(R.id.btn);
        b1=(Button)findViewById(R.id.button2);
        b2=(Button)findViewById(R.id.button3);
        b3=(Button)findViewById(R.id.button4);
        edit=(EditText)findViewById(R.id.edit);
        edit2=(EditText)findViewById(R.id.edit2);
        text=(TextView)findViewById(R.id.textView3);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Integer answer=get_nd_display();
               text.setText(Integer.toString(answer));

            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer ans=multiply();
                text.setText(Integer.toString(ans));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer ans1=subtract();
                text.setText(Integer.toString(ans1));
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer ans2=divide();

                text.setText(Integer.toString(ans2));
            }
        });
    }
    public Integer  get_nd_display()
    {
        String one=edit.getText().toString();
        String two=edit2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a+b;
        return c;


    }
    public Integer multiply() {
        String one = edit.getText().toString();
        String two = edit2.getText().toString();
        int a = Integer.parseInt(one);
        int b = Integer.parseInt(two);
        int c = a * b;
        return c;


    }
    public Integer subtract()
    {
        String one=edit.getText().toString();
        String two=edit2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a-b;
        return c;
    }
    public Integer divide()
    {
        String one=edit.getText().toString();
        String two=edit2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a/b;
        return c;
    }
}
