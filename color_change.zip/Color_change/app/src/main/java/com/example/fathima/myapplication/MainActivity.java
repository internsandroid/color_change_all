package com.example.fathima.myapplication;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;
    EditText e1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        e1=(EditText)findViewById(R.id.editText);

        e1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {


            }

            @Override
            public void afterTextChanged(Editable s) {
                String color=e1.getText().toString();
                color.toLowerCase();
                String str[]=color.split(",");
                boolean r=false,b=false,g=false;
               /* for(int i=0;i<colorArray.length;i++){
                    if(colorArray[i].equals("red")){
                        b1.setBackgroundColor(getResources().getColor(R.color.red));
                    }
                    if(colorArray[i].equals("green")){
                        b2.setBackgroundColor(getResources().getColor(R.color.green));
                    }
                    if(colorArray[i].equals("blue")){
                        b3.setBackgroundColor(getResources().getColor(R.color.blue));
                    }
                }*/
                for(int i=0;i<str.length;i++)
                {
                    if((str[i].equals("red") || str[i].equals("green") || str[i].equals("blue")))
                    {
                        if(str[i].equals("red"))
                        {
                            b1.setBackgroundColor(Color.RED);
                            r=true;
                        }


                        if(str[i].equals("green"))
                        {
                            b2.setBackgroundColor(Color.GREEN);
                            g=true;
                        }


                        if(str[i].equals("blue"))
                        {
                            b3.setBackgroundColor(Color.BLUE);
                            b=true;
                        }


                        if(r==true)
                        {
                            b1.setBackgroundColor(Color.RED);
                        }
                        else
                        {

                            b1.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(b==true)
                        {
                            b3.setBackgroundColor(Color.BLUE);
                        }
                        else
                        {

                            b3.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(g==true)
                        {
                            b2.setBackgroundColor(Color.GREEN);
                        }
                        else
                        {

                            b2.setBackgroundResource(android.R.drawable.btn_default);
                        }


                    }
                    else{

                        if(r==false)
                        {
                            b1.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(g==false)
                        {
                            b2.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(b==false)
                        {
                            b3.setBackgroundResource(android.R.drawable.btn_default);
                        }

                    }
                }
            }
        });
    }
}
