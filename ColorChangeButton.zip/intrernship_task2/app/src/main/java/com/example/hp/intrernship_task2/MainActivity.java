package com.example.hp.intrernship_task2;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
Button red,blue,green;
EditText edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        red=(Button)findViewById(R.id.red);
        blue=(Button)findViewById(R.id.blue);
        green=(Button)findViewById(R.id.green);
        edit=(EditText)findViewById(R.id.edit);

       // edit.addTextChangedListener(this);

        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean r = false, g = false, b = false;
                String color = edit.getText().toString();
                String[] a = color.split(",");


                for (int i = 0; i < a.length; i++) {
                    if (a[i].equals("red") || a[i].equals("green") || a[i].equals("blue")) {
                        if (a[i].equals("red")) {
                            red.setBackgroundColor(Color.RED);
                            r = true;

                        } else if (a[i].equals("green")) {
                            green.setBackgroundColor(Color.GREEN);
                            g = true;
                        } else if (a[i].equals("blue")) {
                            blue.setBackgroundColor(Color.BLUE);
                            b = true;
                        }
                        if (r == true) {
                            red.setBackgroundColor(Color.RED);
                        } else {
                            red.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if (g == true) {
                            green.setBackgroundColor(Color.GREEN);
                        } else {
                            green.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if (b == true) {
                            blue.setBackgroundColor(Color.BLUE);
                        } else {
                            blue.setBackgroundResource(android.R.drawable.btn_default);
                        }
                    } else {
                        if (r == false) {
                            blue.setBackgroundColor(android.R.drawable.btn_default);
                        }
                        if (g == false) {
                            green.setBackgroundColor(android.R.drawable.btn_default);
                        }
                        if (b == false) {
                            red.setBackgroundColor(android.R.drawable.btn_default);
                        }

                    }
                }
            }


            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }
    }
