package com.example.dell.colorz;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {
    Button btn1,btn2,btn3;
    EditText edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
       btn1 = (Button) findViewById(R.id.button);
        btn2 = (Button) findViewById(R.id.button2);
        btn3 = (Button) findViewById(R.id.button3);
        edit = (EditText) findViewById(R.id.editText);
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String s1 = edit.getText().toString();
                String[] itm = s1.split(",");
                int i, length;
                for (i = 0; i < itm.length; i++) {
                    if (itm.equals("red")) {
                        btn1.setBackgroundColor(Color.RED);
                    } else if (itm.equals("green")) {
                        btn2.setBackgroundColor(Color.GREEN);
                    } else {
                        btn3.setBackgroundColor(Color.BLUE);
                    }

                }
            }
        });
    }
}
